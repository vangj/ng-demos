"""
Bayesian Belief Network Generator
"""
