"""
Junction Tree Algorithm
"""
